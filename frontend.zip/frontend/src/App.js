import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Home from './pages/Home';
// import Diagnosis from './pages/Diagnosis';
import SymptomCheckerPage from './pages/SymptomCheckerPage';
import Dashboard from './pages/Dashboard';
import ReportPage from './pages/ReportPage'; // ✅ NEW
import './style/styles.css';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      setIsAuthenticated(true);
    }
  }, []);

  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<Home />} />
          {/* <Route path="/diagnosis" element={<Diagnosis />} /> */}
          <Route path="/symptom-checker" element={<SymptomCheckerPage />} />
          <Route path="/report" element={<ReportPage />} /> 
          <Route 
            path="/dashboard" 
            element={
              isAuthenticated ? (
                <Dashboard />
              ) : (
                <Navigate to="/Da" />
              )
            } 
          />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
