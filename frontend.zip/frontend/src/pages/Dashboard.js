import React, { useState } from 'react';
import '../style/pages/Dashboard.css';
import Navbar from '../components/Navbar';
import ProfileSettings from '../components/ProfileSettings';
import MedicalHistory from '../components/MedicalHistory';
import SavedMedications from '../components/SavedMedications';
import HealthInsights from '../components/HealthInsights';
import PrivacyControls from '../components/PrivacyControls';
import MedicationRecommendation from '../components/MedicationRecommendation';

const Dashboard = () => {
  const [activeTab, setActiveTab] = useState('profile');

  const renderContent = () => {
    switch (activeTab) {
      case 'profile':
        return <ProfileSettings />;
      case 'medicalHistory':
        return <MedicalHistory />;
      case 'medications':
        return <MedicationRecommendation />;
      case 'healthReport':
        return <HealthInsights />;
      case 'settings':
        return <ProfileSettings />;
      case 'privacy':
        return <PrivacyControls />;
      default:
        return <ProfileSettings />;
    }
  };

  return (
    <div className="dashboard-container">
      <Navbar />
      <div className="dashboard-content">
        <h1>Welcome to Your Dashboard</h1>
        <div className="dashboard-tabs">
          <button
            className={activeTab === 'profile' ? 'active' : ''}
            onClick={() => setActiveTab('profile')}
          >
            Profile
          </button>
          <button
            className={activeTab === 'medicalHistory' ? 'active' : ''}
            onClick={() => setActiveTab('medicalHistory')}
          >
            Medical History
          </button>
          <button
            className={activeTab === 'medications' ? 'active' : ''}
            onClick={() => setActiveTab('medications')}
          >
            Medications
          </button>
          <button
            className={activeTab === 'healthReport' ? 'active' : ''}
            onClick={() => setActiveTab('healthReport')}
          >
            Health Report
          </button>
          <button
            className={activeTab === 'settings' ? 'active' : ''}
            onClick={() => setActiveTab('settings')}
          >
            Settings
          </button>
          <button
            className={activeTab === 'privacy' ? 'active' : ''}
            onClick={() => setActiveTab('privacy')}
          >
            Privacy
          </button>
        </div>
        <div className="dashboard-section">{renderContent()}</div>
      </div>
    </div>
  );
};

export default Dashboard;
