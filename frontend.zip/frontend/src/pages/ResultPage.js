import React from 'react';
import '../style/pages/ResultPage.css';



const ResultPage = () => {
  return (
    <div className="result-page">
      <h1>Diagnosis Results</h1>
      <div className="diagnosis-results">
        <h2>Your Diagnosis Results:</h2>
        {/* Placeholder for displaying results */}
      </div>

    </div>
  );
};

export default ResultPage;
