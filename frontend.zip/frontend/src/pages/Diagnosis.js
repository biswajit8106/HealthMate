import React from 'react';
import { useLocation } from 'react-router-dom';

const Diagnosis = () => {
    const location = useLocation();
    const { result } = location.state || { result: null };


    return (
        <div className="diagnosis">
            <h2>Diagnosis Results</h2>
            {result ? (
                <div>
                    <h3>Predicted Disease: {result.predicted_disease}</h3>
                    <p><strong>Description:</strong> {result.description}</p>
                    <p><strong>Precautions:</strong> {result.precautions.join(', ')}</p>
                    <p><strong>Medications:</strong> {result.medications.join(', ')}</p>
                    <p><strong>Diets:</strong> {result.diets.join(', ')}</p>
                    <p><strong>Workouts:</strong> {result.workouts.join(', ')}</p>

                </div>
            ) : (
                <p>No results available.</p>
            )}
        </div>
    );
};

export default Diagnosis;
