import React from 'react';

const Chat = () => {
  return (
    <div className="chat-page">
      <h1>Chat with AI Doctor</h1>
      <p>This is where the chat functionality will be implemented.</p>
    </div>
  );
};

export default Chat;
