import React, { useEffect, useState } from 'react';
import axios from 'axios';

const MedicalHistory = () => {
  const [reports, setReports] = useState([]);

  useEffect(() => {
    const fetchHistory = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('http://localhost:3000/report/history', {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });
        setReports(response.data);
      } catch (error) {
        console.error('Failed to fetch medical history', error);
      }
    };
    fetchHistory();
  }, []);

  return (
    <div className="widget medical-history">
      <h2>Medical History</h2>
      {reports.length === 0 ? (
        <p>No reports found.</p>
      ) : (
        <ul>
          {reports.map((report) => (
            <li key={report.id}>
              <strong>{report.disease}</strong> — {new Date(report.created_at).toLocaleDateString()}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default MedicalHistory;
