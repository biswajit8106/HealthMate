import React, { useEffect, useState } from 'react';
import axios from 'axios';

const HealthInsights = () => {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchReports = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('http://localhost:3000/health/reports', {
          headers: { Authorization: `Bearer ${token}` },
        });
        setReports(response.data);
      } catch (err) {
        setError('Failed to fetch health reports.');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchReports();
  }, []);

  if (loading) return <p>Loading health reports...</p>;
  if (error) return <p className="error">{error}</p>;

  return (
    <div className="health-insights">
      <h2>Health Reports</h2>
      {reports.length === 0 ? (
        <p>No health reports found.</p>
      ) : (
        <ul>
          {reports.map((report) => (
            <li key={report.id}>
              <strong>{report.title}</strong> - {new Date(report.date).toLocaleDateString()}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default HealthInsights;
