import React, { useState, useEffect } from 'react';
import axios from 'axios';

const MedicationRecommendation = () => {
  const [medicines, setMedicines] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchMedicines = async () => {
      try {
        const response = await axios.get('/api/medicine/common_medicine_info');
        setMedicines(response.data.medicines);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchMedicines();
  }, []);

  return (
    <div className="medication-recommendation">
      <h3>Common Medication Information</h3>
      {loading ? (
        <p>Loading medicine information...</p>
      ) : error ? (
        <p className="error">Error: {error}</p>
      ) : (
        <div className="recommendation-list">
          <table>
            <thead>
              <tr>
                <th>Medicine Name</th>
                <th>Uses</th>
                <th>Precautions</th>
              </tr>
            </thead>
            <tbody>
              {medicines.map((medicine, index) => (
                <tr key={index}>
                  <td>{medicine['Medicine Name']}</td>
                  <td>{medicine.Uses}</td>
                  <td>{medicine.Precautions}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <p className="disclaimer">
        This is an AI generated prediction! Always consult with a specialized professional doctors before taking any medication.
      </p>
    </div>
  );
};

export default MedicationRecommendation;
