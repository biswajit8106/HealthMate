import React from 'react';
// import './style/components/Chatbot.css';


const Chatbot = () => {
  return (
    <div className="chatbot-container">
      <h3>AI Health Assistant</h3>
      <div className="chatbot-interface">
        <h3>AI Health Assistant</h3>
        <input type="text" placeholder="Enter your symptoms..." onChange={(e) => setSymptoms(e.target.value)} />
        <button onClick={handleSubmit}>Check Symptoms</button>

        <div className="chatbot-response">
      <div className="chatbot-response">
        {response && <p>{response}</p>}
      </div>

        </div>
      </div>

    </div>
  );
};

export default Chatbot;
