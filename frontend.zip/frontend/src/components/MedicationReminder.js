import React, { useState } from 'react';
// import './style/components/MedicationReminder.css';


const MedicationReminder = () => {
  const [reminders, setReminders] = useState([]);

  const addReminder = () => {
    const newReminder = {
      id: Date.now(),
      medication: 'New Medication',
      time: '12:00 PM'
    };
    setReminders([...reminders, newReminder]);
  };


  return (
    <div className="medication-reminder">
      <h3>Medication Reminder</h3>
      <div className="reminder-list">
        {reminders.map((reminder, index) => (
          <div key={index} className="reminder-item">
            {/* Reminder details */}
          </div>
        ))}
      </div>
      <button onClick={addReminder}>Add Reminder</button>
    </div>
  );
};

export default MedicationReminder;
